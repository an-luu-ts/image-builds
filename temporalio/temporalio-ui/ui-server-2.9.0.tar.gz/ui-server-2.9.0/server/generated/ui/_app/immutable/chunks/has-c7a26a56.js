import{i as r}from"./is-44021919.js";const a=(t,e)=>Object.prototype.hasOwnProperty.call(t,e),n=t=>r(t)?!!Object.keys(t).length:!1;export{n as a,a as h};
