function o(i){const s=i;return(s==null?void 0:s.statusCode)!==void 0&&(s==null?void 0:s.statusText)!==void 0&&(s==null?void 0:s.response)!==void 0}export{o as i};
