import{w as s}from"./index-ecd41ae6.js";import{p as a}from"./persist-store-07cc3f48.js";const o=a("lastNamespace","default"),p=s([]);export{o as l,p as n};
