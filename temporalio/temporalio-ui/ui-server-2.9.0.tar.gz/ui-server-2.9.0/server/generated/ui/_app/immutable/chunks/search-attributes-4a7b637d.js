import{w as t}from"./index-ecd41ae6.js";const s=t();export{s};
