# ui server E2E tests

[![E2E Tests](https://github.com/temporalio/ui-server/actions/workflows/e2e.yml/badge.svg)](https://github.com/temporalio/ui-server/actions/workflows/e2e.yml)

E2E specifies a set of tests that run against a real Temporal server

